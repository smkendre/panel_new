<button class="open-button" onclick="openForm()">Chat</button>

<div class="chat-popup" id="myForm">
  <iframe src="https://vimeo.com/live/interaction_tools/live_event/3659241" frameborder="0" allowfullscreen width="100%" height="500px"></iframe>
</div>
