<div id="menu4" class="mainscreenright">
  <h2>Help <a href="javascript:" onclick="hideDiv('menu4');"><i
              class="fa fa-close handoutsrightclose"></i></a></h2>
  <div class="screenright2">

  </div>
</div>