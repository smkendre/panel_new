
            <div id="menu3" class="mainscreenright">
              <h2>Sponsor Chat <a href="javascript:" onclick="hideDiv('menu3');"><i
                          class="fa fa-close handoutsrightclose"></i></a></h2>
              <div class="screenright1">
                  <div class="attendechatmainbox">
                      <div class="attendechatbox1">
                          <h6>Viraj Mehta <span>10:30 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox1">
                          <h6>Viraj Mehta <span>10:34 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox1">
                          <h6>Rakesh Yadav <span>10:40 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox2">
                          <h6>Hiren Mistry <span>10:40 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox1">
                          <h6>Viraj Mehta <span>10:34 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox1">
                          <h6>Rakesh Yadav <span>10:40 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechatbox2">
                          <h6>Hiren Mistry <span>10:40 AM</span></h6>
                          <p>Hello! helps Indian Websites their Sales and Customer support! Talk to me here...</p>
                      </div>
                      <div class="attendechattextsend">
                          <textarea rows="2" cols="2" id="" name=""
                              placeholder="Type your message here..."></textarea>
                          <button type="submit" id="submit" name="submit" class="button"><i
                                  class="fa fa-send-o"></i></button>
                      </div>
                  </div>
              </div>
          </div>
