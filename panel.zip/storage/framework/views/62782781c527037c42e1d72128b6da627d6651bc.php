<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>

<div class="innercontainwrapper">
    	
      <div class="group clearboth">

      <div class="row conference_video">
        <div class="agendacol1">
        <h2>Session - <?php echo e($live_session->assm_title); ?></h2>
        <br />
        <div class="mainscreenvideo">
            <iframe src="<?php echo e($live_session->assm_url); ?>" frameborder="0" allowfullscreen width="100%" height="500px"></iframe>
        </div></div>
       
         
      </div>
      
      <hr>
      
      </div>
      </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
<script>
    video_tracking('<?php echo e(url($live_session->assm_url)); ?>', 'ondemand', '<?php echo e($live_session->assm_id); ?>');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/expresscomputer/digitalsmb/resources/views/pages/session.blade.php ENDPATH**/ ?>