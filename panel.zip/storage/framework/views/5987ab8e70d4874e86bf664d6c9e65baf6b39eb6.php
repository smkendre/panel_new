<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>

<div class="innercontainwrapper">
    	
      <div class="group clearboth">
          <div class="innercol1 abouttext">
              <h2>About Conference</h2>
              <h3>Data Breaches in the post pandemic world</h3>
              <p>As organisations across industries build their remote working infrastructure to align themselves with the new normal of working, cyber immunity of their employees and data is crucial. There have been various incidences on data breaches in India in the recent times. One of the major factors behind these breaches is the absence of a robust a robust policy framework to protect businesses and consumers to safeguard themselves.</p>
              <p>Securing data of customers, employees and organisations becomes paramount owing to the growing data-centricity in the modern work environment. Furthermore, as more organisations embrace a mobile-driven remote work approach, they have little control over employees' location and devices, which could expand the threat surface. In this environment, organisations need to ensure robust authentication and access management in their remote-enabled IT infrastructure. Digital tools and best practices around password security and password hygiene become paramount in this direction.</p>
              <p>Recognising this, CRN India has joined forces with LogMeIn to conduct an exclusive virtual conference which will focus on every aspect of data security and password management in a remote-centric world. The conference will feature leading IT decision makers and industry experts who will share their insights through various sessions including keynote, panel discussion and fireside chat.</p>
          </div>
          <div class="innercol2">
              <div class="lobbyrightvideo">
                  <h3>Welcome to the Conference</h3>
                  <iframe src="https://player.vimeo.com/video/559806962" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
              </div>
              
              <!--<div class="aboutright">
                  <h3>Major highlights</h3>
                  <div class="aboutrightcon">
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/data-security.png" alt="" >
                          <span>Trends and challenges pertaining to data and password security and management</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/success-stories.png" alt="" >
                          <span>Best practices and success stories</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/remote-working.png" alt="" >
                          <span>Leveraging emerging technologies to enable a secure remote working infrastructure</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/charting.png" alt="" >
                          <span>Charting the roadmap ahead</span>
                      </p>
                  </div>
              </div>-->
          </div>
      </div>
      
      <hr>
      
      <h2> Sessions <a href="<?php echo e(url('agenda')); ?>">View All <i class="fas fa-angle-double-right"></i></a></h2>
      
      <div class="group clearboth">
      <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="aboutagenda aboutagendabox1">
            <a href="#">
                  <h3>8 JUNE, 2021 (<?php echo e(date('h:i A', strtotime($row->assm_start_time))); ?> -
                                    <?php echo e(date('h:i A', strtotime($row->assm_end_time))); ?> IST)</h3>
                  <h4><?php echo e($row->assm_title); ?></h4>

                        <?php if(!empty($row->speakers) && count($row->speakers) > 0): ?>

                                <?php $__currentLoopData = $row->speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span>
                    <img src="<?php echo e($sp->ap_image); ?>" alt="" >
                  </span>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        <?php endif; ?>


                        <?php if(!empty($row->moderator)): ?>
                       
                            <span>
                    <img src="<?php echo e($row->moderator->ap_image); ?>" alt="" >
                  </span>

                        <?php endif; ?>

                        <?php if(!empty($row->panelists) && count($row->panelists) > 0): ?>
                       
                            <?php $__currentLoopData = $row->panelists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span>
                    <img src="<?php echo e($sp->ap_image); ?>" alt="" >
                  </span>
                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                  
              </a>
              <?php if($row->assm_url): ?>
              <div class="btn1">   <a href="javascript:" onclick="video_tracking('<?php echo e($row->assm_url); ?>', 'ondemand', <?php echo e($row->assm_id); ?>)"
                  class="join_link conboxbtn" id="join-<?php echo e($row->assm_id); ?>" data-timeLeft="10">Watch
                  Now</a></div>
              <?php endif; ?>
              <!-- <div class="btn1"><a href="#">Join Session</a> -->
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      <hr>
      
      <h2>Speakers <a href="<?php echo e(url('speakers')); ?>">View All <i class="fas fa-angle-double-right"></i></a></h2>
      
      <div class="group clearboth">
      <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="speakerbox speakerboxheight">
            <img src="<?php echo e($sp->ap_image); ?>" alt="">
              <h4><?php echo e($sp->ap_name); ?></h4>
              <p><?php echo e($sp->ap_designation); ?>, <?php echo e($sp->ap_company); ?></p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
      </div>
      
  </div>
  
  
  

<?php $__env->stopSection(); ?>


<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/pages/conference.blade.php ENDPATH**/ ?>