<!doctype html>
<html lang="en">

<head>
  <title>Data Breaches in the Pandemic World and Beyond  </title>
  <meta name="description" content="">

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0, minimal-ui" />

  <link rel="shortcut icon" href="crnfavicon.png">
  <link rel="icon" type="image/png" href="crnfavicon.png">

  <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Nunito:ital,wght@0,200;0,300;0,400;0,600;0,700;0,800;0,900;1,200;1,300;1,400;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

<!--<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

<link rel="stylesheet" href="<?php echo e(asset('css/jquery.fancybox.min.css')); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php echo e(asset('css/jquery.datetimepicker.min.css')); ?>" type="text/css" media="screen" />

<link href="<?php echo e(asset('css/common-text.css?1.1')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('css/common-layout.css?2.0.1')); ?>" rel="stylesheet" type="text/css" />
<link href="<?php echo e(asset('css/popup.css?2.0.4')); ?>" rel="stylesheet" type="text/css" />
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/resrponsive.css?1.3')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css?1.2')); ?>">

<script>
  var JS_URL = "<?php echo e(url('/')); ?>/";
</script>
</head>

<body>


<div class="loader"><span></span></div>

    
<div class="topmainbg">
    	<div class="topmainleft"><a href="index.html"><img src="<?php echo e(asset('images/crn-logo.png')); ?>" alt="" ></a></div>
        <div class="innertopmenubg">
            <a  class="toprightlink" ><i class="fa fa-cog"></i></a>
            <div class="toprightlinkshow">
                <ul class="nobullet">
                    <li><a href="<?php echo e(url('profile')); ?>"> Profile</a></li>
                    <!-- <li><a data-fancybox data-src="#viewpopup" data-options='{"touch": false}' href="javascript:;">View Profile</a></li> -->
                    <li><a href="<?php echo e(url('logout')); ?>">Logout</a></li>
                </ul>
            </div>
        </div>
        <div class="attendingbox">
        
        <a data-fancybox data-src="#totalattending" data-options='{"touch": false}'
          href="javascript:;" <?php echo e((Request::segment(1) == 'agenda') ? 'style="display: none;"': ''); ?>>Total Attending : <u id="totalcount">0</U></a>

          <a <?php echo (Request::segment(1) == 'lobby') ? 'style="display: block;"': 'style="display: none;"'; ?> data-fancybox data-src="#nowattending" data-options='{"touch": false}'
          href="javascript:;">Now Attending : <u id="livecount">0</U></a>
        </div>
    </div>
    
    <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    
    
    <div class="mainfooter">
            <div class="mainfooterleft"><a href="https://www.crn.in/" target="_blank"><img src="images/crn-logo.png" alt="" ></a>  Copyright &copy; The Indian Express [P] Ltd. All Rights Reserved. <span>|</span> <a href="https://www.crn.in/privacy-policy/" target="_blank">Privacy Policy</a></div>
            <div class="mainfooterright">
                <a href="https://www.facebook.com/ComputerResellerNews/" target="_blank"><i class="fab fa-facebook"></i></a>
                <a href="https://www.linkedin.com/crn-india-online" target="_blank"><i class="fab fa-linkedin"></i></a>
                <a href="https://twitter.com/crndotin/" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://www.instagram.com/crnindia/" target="_blank"><i class="fab fa-instagram"></i></a>
            </div>
        </div>

    
    
    <?php echo $__env->make('layouts.profile', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.requestmeeting', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <?php echo $__env->make('layouts.nowattending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.poll', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('layouts.askquestion', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="messagePopup" class="popmain3">
    <div class="popmainheading">Message</div>
    <div class="popmain1con1">
      <div class="popupformmain1">
        <p id="successMsg"><label></label></p>
      </div>
    </div>
  </div>


  <div id="announsmessage" class="popmain3">
        <div class="popmainheading">Announcement Message</div>
        <div class="popmain1con1">
            <div class="popupformmain1">
                <p class="tac">The role of ICT in overcoming challenges during Covid19 and the road ahead </p>
                <p class="desc">is live now</p>
                <br>
                <div class="actionBtn btn1"><a href="">Join Now</a></div>
            </div>
        </div>
        <button type="button" data-fancybox-close="" class="fancybox-button fancybox-close-small"
            title="Close"></button>
    </div>


  <input type="hidden" name="name" id="name" value="<?php echo e(session()->get('username')); ?>" />
  <input type="hidden" name="user_id" id="user_id" value="<?php echo e(session()->get('daid')); ?>" />
  <input type="hidden" name="email" id="email" value="<?php echo e(session()->get('useremail')); ?>" />
  <input type="hidden" name="job_title" id="job_title" value="<?php echo e(session()->get('job_title')); ?>" />
  <input type="hidden" name="company" id="company" value="<?php echo e(session()->get('company')); ?>" />
  <input type="hidden" name="page" id="page" value="<?php echo e(Request::segment(1)); ?>" />
  <input type="hidden" name="live_session" id="live_session" value="<?php echo e((isset($_COOKIE['event_id'])) ? $_COOKIE['event_id']: ''); ?>" />

  <script type="text/javascript" src="https://s.ebpd.in/jquery-3.3.1.min.js"></script>
  <script type="text/javascript" src="https://s.ebpd.in/ajax-1.9.0.min.js"></script>
  <script type="text/javascript" src="https://s.ebpd.in/source-tracking.js"></script>

  <script src="<?php echo e(asset('js/jquery.balance.js')); ?>" type="text/javascript"></script>
<script type="text/javascript">
	$(window).load(function() {
		$('.aboutagendabox1').balance() ;
		$('.speakerboxheight').balance() ;
	});
</script>

<script type="text/javascript">
	$(document).ready(function(){
	  $(".toprightlink").click(function(){
		$(".toprightlinkshow").toggle();
	  });
	});
</script>


<script type="text/javascript" src="<?php echo e(asset('js/jquery.fancybox.min.js')); ?>"></script>

<script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>
<script type="text/javascript" src="<?php echo e(asset('js/jquery.datetimepicker.full.min.js')); ?>"></script>
<script type="text/javascript" src="https://dev.expressbpd.in/socket.io/socket.io.js"></script>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"> </script>

<script type="text/javascript" src="<?php echo e(asset('js/main.js?2.1.5')); ?>"></script>

<script type="text/javascript">
  $(document).ready(function(){

    const socket = io("https://dev.expressbpd.in");

    $('#datetimepicker3').datetimepicker({
      format:'d.m.Y H:i:s',
      inline:true,
      lang:'ru',
      startDate: "today",
      minTime:'8:00',
      maxTime:'21:00',
      onChangeDateTime:function(dp,$input){
        var dNow = new Date(dp);
        var hours = dNow.getHours();
        var minutes =  dNow.getMinutes();

        if (hours < 10) hours = "0" + hours;
        if (minutes < 10) minutes = "0" + minutes;

        var selected_date = dNow.getDate() + '-' + (dNow.getMonth()+1)  + '-' + dNow.getFullYear();
        var selected_time = hours + ':' + minutes;

        $("#selected_date").text(selected_date);
        $("#selected_time").text(selected_time);
        $("#sdate").val(selected_date);
        $("#stime").val(selected_time); 
       
      }
    });

    $("#meetingFrm").validate({
      rules:{
        msg:{required: true}
      },
      messages:{
        msg:{required: "Please enter message"}
      },
      submitHandler: function(form) {            

        $.ajax({
          url: 'request-meeting',
          data:{msg: $("#msg").val(), _token: $("input[name='_token']").val(), sdate: $("#sdate").val(), stime: $("#stime").val(), sponsor: $("#sponsor").val() },
          type: 'post',
          dataType: 'json',
          success: function(response){
            if(response.status == 200){
              $.fancybox.close();
              $("#successMsg label").text("Request send successfully");
              $.fancybox.open($("#messagePopup"));
            }else{
              $.fancybox.open($("#resigterpopup"));
            }
          }
        });

        return false;
     
        // if($("#email").val() == 'viraj.mehta@indianexpress.com')
        //$("#loginFrm")[0].submit();
        //else
        // $.fancybox.open($("#loginpop").html());
      }
    });

    $("#pollFrm").validate({
        rules:{
            poll_experience:{required: true}
        },
        messages:{
            poll_experience:{required: "Please select question answer"}
        },
        submitHandler: function(form) {            
  
            const id = document.getElementById('pollid').value;
            const pollanswer = $("input[name='poll_experience']:checked").val();
        
            const msg = { pollid: id, userid: <?php echo e(session()->get('daid')); ?>, pollanswer: pollanswer }
            socket.emit('pollResponse', msg);

            $("#successMsg label").text("Thank you. Your response noted");
            $.fancybox.open($("#messagePopup"));
  
            setTimeout(function() {
              parent.$.fancybox.close();


              $.fancybox.close();

        }, 3000);
          return false;
       
        
        }
      });

               
    $("#qsansFrm").validate({
      rules:{
        question:{required: true}
      },
      messages:{
        question:{required: "Please enter question"}
      },
      submitHandler: function(form) {            
        // $('#qnaBtn').button('loading');
        $('#qnaBtn').prop('disabled', true);

        /* perform processing then reset button when done */
        $.fancybox.close();
        $(".loader").fadeIn("slow");


        $.ajax({
          url: "<?php echo e(url('ask-question')); ?>",
          data:{question: $("#question").val(), _token: $("input[name='_token']").val()},
          type: 'post',
          dataType: 'json',
          success: function(response){
            if(response.status == 200){
              $.fancybox.close();
              $("#successMsg label").text("Question submitted successfully");
               socket.emit("qna-page-load", <?php echo e(session()->get('daid')); ?>);              
              $(".loader").fadeOut("slow");

              $.fancybox.open($("#messagePopup"));
              
            }else{
             // $.fancybox.open($("#resigterpopup"));
            }
          }
        });

        return false;
     
        // if($("#email").val() == 'viraj.mehta@indianexpress.com')
        //$("#loginFrm")[0].submit();
        //else
        // $.fancybox.open($("#loginpop").html());
      }
    });
  });
</script>
<script type="text/javascript" src="<?php echo e(asset('js/script.js?1')); ?>"></script>


<script type="text/javascript">
	// $(document).ready(function() {
	// 	$("data-fancybox").fancybox();
	// });
	// $(document).ready(function() {
	// 	$(".fancybox").fancybox();
	// });
	/*window.jQuery(document).ready(function() {
		var box = $('#introvideo');
		$.fancybox.open(box);
  });*/
  
  function sendmessage(id, name, email){

document.getElementById("to_id").value = id;
document.getElementById("to_email").value = email;
document.getElementById("receiver_name").value = name;

//document.getElementById('lblName').innerHTML = "Sending Message to " + name;
}
</script>

<script type="text/javascript">
	$(window).load(function() {
		$(".loader").fadeOut("slow");
	})
</script>
<?php echo $__env->yieldContent('js_after'); ?>
</body>

</html>
<?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/auth/app.blade.php ENDPATH**/ ?>