<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
   
    <div class="innercontainwrapper">
       
        <h2>Agenda</h2>
        
        <div class="group clearboth" id="agendaWrapper">
         
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
   <script type="text/javascript">

    ajax_agenda_load();
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/expresscomputer/digitalsmb/resources/views/layouts/agenda.blade.php ENDPATH**/ ?>