

    <div id="nowattending" class="popmain1">
      <div class="popmainheading">Now Attending</div>
      <div class="popmain1con1">
          <div class="popupformmain1" id="user-list">
           
          </div>

      </div>
  </div>



  
  <div id="totalattending" class="popmain1">
    <div class="popmainheading">Total Attending</div>
    <div class="popmain1con1">
        <div class="popupformmain1" id="total-user-list">

        </div>
    </div>
</div><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/layouts/nowattending.blade.php ENDPATH**/ ?>