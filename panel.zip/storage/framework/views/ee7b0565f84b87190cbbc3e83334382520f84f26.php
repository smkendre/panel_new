

<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>

<div class="innercontainwrapper">
    	
      <div class="group clearboth">

      <div class="row conference_video">
        <div class="innercol1">
        <h2>Session - <?php echo e($live_session->assm_title); ?></h2>
        <div class="mainscreenvideo">
            <iframe src="<?php echo e($live_session->assm_webinar_id); ?>" frameborder="0" allowfullscreen width="100%" height="500px"></iframe>
        </div></div>
        <div class="innercol2">
            <h2>Attendees</h2>
            <div id="nowattendingSidebar" class="popmain1" style="display: block;">
      <div class="popmainheading">Now Attending</div>
      <div class="popmain1con1">
          <div class="popupformmain1" id="user-list-sidebar">
           
          </div>

      </div>
  </div>
  <h2>QnA</h2>
            <div id="qnA" class="popmain1" style="display: block;">
      <div class="popmainheading">QnA</div>
      <div class="popmain1con1">
          <div class="popupformmain1" id="qna-list">
           
          </div>

      </div>
  </div>
        </div>
      </div>
          <div class="innercol1 abouttext">
              <h2>About Conference</h2>
             <?php echo e($live_session->assm_description); ?>

          </div>
          <div class="innercol2">
              <!-- <div class="lobbyrightvideo">
                  <h3>Welcome to the Conference</h3>
                  <iframe src="https://player.vimeo.com/video/559806962" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>
              </div> -->
              
              <!--<div class="aboutright">
                  <h3>Major highlights</h3>
                  <div class="aboutrightcon">
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/data-security.png" alt="" >
                          <span>Trends and challenges pertaining to data and password security and management</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/success-stories.png" alt="" >
                          <span>Best practices and success stories</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/remote-working.png" alt="" >
                          <span>Leveraging emerging technologies to enable a secure remote working infrastructure</span>
                      </p>
                      <p>
                          <img src="https://lp.crn.in/lmi/iam-virtual-conference/images/charting.png" alt="" >
                          <span>Charting the roadmap ahead</span>
                      </p>
                  </div>
              </div>-->
          </div>
      </div>
      
      <hr>
      
      <h2> Sessions <a href="<?php echo e(url('agenda')); ?>">View All <i class="fas fa-angle-double-right"></i></a></h2>
      
      <div class="group clearboth">
      <?php $__currentLoopData = $sessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="aboutagenda aboutagendabox1">
            <a href="#">
                  <h3>8 JUNE, 2021 (<?php echo e(date('h:i A', strtotime($row->assm_start_time))); ?> -
                                    <?php echo e(date('h:i A', strtotime($row->assm_end_time))); ?> IST)</h3>
                  <h4><?php echo e($row->assm_title); ?></h4>

                        <?php if(!empty($row->speakers) && count($row->speakers) > 0): ?>

                                <?php $__currentLoopData = $row->speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span>
                    <img src="<?php echo e($sp->ap_image); ?>" alt="" >
                  </span>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        <?php endif; ?>


                        <?php if(!empty($row->moderator)): ?>
                       
                            <span>
                    <img src="<?php echo e($row->moderator->ap_image); ?>" alt="" >
                  </span>

                        <?php endif; ?>

                        <?php if(!empty($row->panelists) && count($row->panelists) > 0): ?>
                       
                            <?php $__currentLoopData = $row->panelists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span>
                    <img src="<?php echo e($sp->ap_image); ?>" alt="" >
                  </span>
                          
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                  
              </a>
              <?php if($row->assm_url): ?>
              <div class="btn1">   <a href="javascript:" onclick="video_tracking('<?php echo e($row->assm_url); ?>', 'ondemand', <?php echo e($row->assm_id); ?>)"
                  class="join_link conboxbtn" id="join-<?php echo e($row->assm_id); ?>" data-timeLeft="10">Watch
                  Now</a></div>
              <?php endif; ?>
              <!-- <div class="btn1"><a href="#">Join Session</a> -->
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      <hr>
      
      <h2>Speakers <a href="<?php echo e(url('speakers')); ?>">View All <i class="fas fa-angle-double-right"></i></a></h2>
      
      <div class="group clearboth">
        <?php if(!empty($speakers)): ?>
      <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="speakerbox speakerboxheight">
            <img src="<?php echo e($sp->ap_image); ?>" alt="">
              <h4><?php echo e($sp->ap_name); ?></h4>
              <p><?php echo e($sp->ap_designation); ?>, <?php echo e($sp->ap_company); ?></p>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </div>
      
  </div>
  
  
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
<script>
     const socket = io("https://dev.expressbpd.in/");
     socket.emit("liveAttendeesCount", {
    name: $("#name").val(),
    email: $("#email").val(),
    jobtitle: $("#job_title").val(),
    company:   $("#company").val(),
    events: <?php echo e($live_session->assm_id); ?>,  //this indicates event id in dbeavrce
    userId: $("#user_id").val()
  });

  function get_questions(){
   
    $.ajax({
        url: "<?php echo e(url('get_questions')); ?>",
        data:{ _token: $("input[name='_token']").val()},
        type: 'post',
        dataType: 'html',
        success: function(response){
            $("#qna-list").html(response);
            
        }
          
    });
  }
  get_questions();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/pages/lobby.blade.php ENDPATH**/ ?>