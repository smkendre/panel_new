
    <div class="innerheadermain">
    	<div class="innerheaderimg"><img src="<?php echo e(asset('images/header1.jpg')); ?>" alt="" ></div>
        <div class="innerheadermenu">
        	<ul class="nobullet">
            	<li>
                	<a href="<?php echo e(url('conference')); ?>" <?php echo e((Request::segment(1) == 'conference') ? 'class=active': ''); ?>>
                    	<i class="fas fa-home"></i>
						<span>Info</span>
                    </a>
                </li>
                <li>
                	<a href="<?php echo e(url('agenda')); ?>" <?php echo e((Request::segment(1) == 'agenda') ? 'class=active': ''); ?>>
                    	<i class="far fa-file-alt"></i>
						<span>Agenda</span>
                    </a>
                </li>
                <li>
                	<a href="<?php echo e(url('speakers')); ?>" <?php echo e((Request::segment(1) == 'speakers') ? 'class=active': ''); ?>>
                    	<i class="fas fa-microphone"></i>
						<span>Speakers</span>
                    </a>
                </li>
                <li>
                	<a href="<?php echo e(url('assets')); ?>" <?php echo e((Request::segment(1) == 'assets') ? 'class=active': ''); ?>>
                    	<i class="fas fa-handshake"></i>
						<span>Meet LogMeIn</span>
                    </a>
                </li>
                <li>
                	<a data-fancybox data-src="#requestameeting" data-options='{"touch": false}' href="javascript:;">
                    	<i class="fas fa-bug"></i>
						<span>Request a Meeting</span>
                    </a>
                </li>

                <li>
                <a data-fancybox data-src="#askaquestion" data-options='{"touch": false}' href="javascript:;">
                <i class="fas fa-question-circle" aria-hidden="true"></i>

                <span>Ask a Question</span>
            </a>
                </li>
                
            </ul>
        </div>
    </div>
    
    <?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/layouts/menu.blade.php ENDPATH**/ ?>