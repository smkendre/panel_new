<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
   
    <div class="innercontainwrapper">
       
        <h2>Agenda</h2>
        
        <div class="group clearboth" id="agendaWrapper">
         
        </div>
        
    </div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>
   <script type="text/javascript">

  $(".countdown").each(function () {

$(".live_link").hide();
$(".joinNowLink").hide();

var dt = $(this).attr("data-date");
var tm = $(this).attr("data-time");
var url = $(this).attr("data-url");
var id = $(this).attr("id");
var etm = $(this).attr("data-end-time");
var title = $(this).attr("data-title");

// console.log(dt + "" + tm);

// Set the date we're counting down to
var countDownDate = new Date(dt + " " + tm).getTime();
// console.log(
//   new Date(dt + " " + etm)
//     .toLocaleTimeString()
//     .replace(/([\d]+:[\d]{2})(:[\d]{2})(.*)/, "$1$3")
// );

// Update the count down every 1 second
var x = setInterval(function () {
  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor(
    (distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60)
  );
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  if (hours < 10) hours = "0" + hours;
  if (minutes < 10) minutes = "0" + minutes;
  if (seconds < 10) seconds = "0" + seconds;

  // Output the result in an element with id="demo"
  $("#" + id).html(
    '<img src="' +
      JS_URL +
      'images/clock.png" alt="">' +
      days +
      " Days " +
      hours +
      " Hrs " +
      minutes +
      " Min " +
      seconds +
      " Sec "
  );
  // console.log(distance);
  // If the count down is over, write some text
  //console.log(days + " Days " + hours + " Hrs " + + minutes + " Min ");
  // var content =
  //   ' <div id="announsmes" class="popmain3"><div class="popmainheading">LIVE SESSION ALERT</div><div class="popmain1con1"><div class="popupformmain1"><h5 class="livesessiontitle">' +
  //   title +
  //   ' is <i>live Now</i></h5><br><div class="btn2 tac"><a href="#">Join Now</a></div></div></div></div>';

  if (days == 0 && hours == 0 && minutes < 6) {
    // $("#join-" + id).attr("href", url);
    $("#join-" + id).attr("href", url);

    $("#join-" + id).attr("data-timeLeft", minutes);
  //  $(".conzoomlink a").attr("href", url);
  }
  // console.log("distance: " + distance);

  // if (days == 0 && hours == 0 && minutes == 0 && seconds == 2) {
  //   $(".livesessiontitle").html(title + " is <i>live Now</i>");
  //   $.fancybox.open($("#livealert"));
  // }
  if (distance < 0) {
    $("#live-" + id).show();
    $("#join-" + id).show();
   // $("#directLink-" + id).removeClass("hide");
    $("#" + id).html("");
    $("#parent-" + id).addClass("popconfboxactive");
   // $(".conzoomlink a").attr("href", url);
    $("#join-" + id).attr("href", url);
    $("#join-" + id).attr("data-timeLeft", minutes);
    clearInterval(x);
  }

  // if (days == 0 && hours == 0 && minutes == -10) {
  //   $.fancybox.open($("#livealert"));
  // }
}, 1000);
});
    

    ajax_agenda_load();
</script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/layouts/agenda.blade.php ENDPATH**/ ?>