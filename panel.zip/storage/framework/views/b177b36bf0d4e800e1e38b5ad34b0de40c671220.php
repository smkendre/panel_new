<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
     
    
    <div class="innercontainwrapper">
       
      <h2>Welcome to LogMeIn Content Hub</h2>
      
      <div class="group clearboth">
        <div class="meetaboutleft"><img src="images/last-pass-logo.png" alt="" ></div><div class="meetaboutright">Technology that works the way you do. We build products that simplify the way people interact with each other and the world around them. We enable people to drive meaningful insights, deeper relationships, and better outcomes for all with frictionless technology.</div>
      </div>
      
      <hr>
      
      
      <div class="headingtext1">Download Assets</div>
      <div class="group clearboth tac">
        <?php $__currentLoopData = $pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pdf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="assetsbox1">
              <a href="<?php echo e($pdf->ad_url); ?>" target="_blank" data-id="<?php echo e($pdf->ad_id); ?>" class="pdficon assetTrack"><img src="images/pdf-icon.png" alt="" ></a>
          <h6><?php echo e($pdf->ad_title); ?></h6>
          <div class="btn1"><a href="<?php echo e($pdf->ad_url); ?>" data-id="<?php echo e($pdf->ad_id); ?>" target="_blank" class="assetTrack">Download Assets</a></div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      <hr>
      
      <div class="headingtext1">Watch Videos</div>
      
      <div class="group clearboth">
          <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="assetsbox spvideoboxheight">
              <iframe src="<?php echo e($video->ad_url); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
              <h6><?php echo e($video->ad_title); ?></h6>
              <div class="btn1"><a class="fancybox assetTrack" data-id="<?php echo e($video->ad_id); ?>" data-fancybox-type="iframe" href="<?php echo e($video->ad_url); ?>">Watch Now</a></div>
          </div>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      <hr>
      
      <div class="headingtext1">Connect with LogMeIn Partner Team</div>
      
      <div class="group clearboth">
          <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="speakerbox speakerboxheight">
        <img src="<?php echo e($row->ap_image); ?>" alt="">
              <h4><?php echo e($row->ap_name); ?></h4>
              <p class="speakerboxheight1"><?php echo e($row->ap_designation); ?></p>
        <h6><a href="<?php echo e($row->ap_description); ?>" target="_blank"><i class="fab fa-linkedin"></i></a></h6>
          </div>
         
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
  </div>
  
  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/pages/resources.blade.php ENDPATH**/ ?>