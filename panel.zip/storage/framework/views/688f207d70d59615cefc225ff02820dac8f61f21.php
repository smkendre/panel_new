

<?php $__env->startSection('content'); ?>
<?php echo csrf_field(); ?>
    
    <div class="innercontainwrapper">
       
       <h2>Speakers</h2>
       
       <div class="group clearboth">
           <?php $__currentLoopData = $speakers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="speakerbox speakerboxheight">
               <img src="<?php echo e($row->ap_image); ?>" alt="">
               <h4><?php echo e($row->ap_name); ?></h4>
               <p><?php echo e($row->ap_designation); ?>, <?php echo e($row->ap_company); ?></p>
           </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
       </div>
       
   </div>
   
   
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/expresscomputer/digitalsmb/resources/views/pages/speakers.blade.php ENDPATH**/ ?>