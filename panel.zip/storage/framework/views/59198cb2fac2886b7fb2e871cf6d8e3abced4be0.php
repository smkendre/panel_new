    



    <?php $__env->startSection('content'); ?>
   
    <div class="loginbg">
    	
        <div class="eclogo"><a href="<?php echo e(url('/')); ?>"></div>
        
        <div class="datetime"><i>14</i><h6><span>October 2022</span>11:30PM - 12:30PM</h6></div>
        
        <div class="loginbox">
        	<div class="loginboxlogo"><a href="<?php echo e(url('/')); ?>"></a></div>
            <form action="<?php echo e(route('userlogin')); ?>" method="POST" id="loginFrm">
            <?php echo csrf_field(); ?>
    
                <h3><i>LOGIN</i></h3>
                <!-- <h6>If you have already registered, please log in</h6> -->
                <label>Email Address</label>
                <input type="email" id="email" name="email" maxlength="128" value="<?php echo e(app('request')->input('email')); ?>" required>
                <div class="group clearboth"><button type="submit" >Login</button></div>
            </form>
        </div>
        
        
        
        
    </div>
    <div id="resigterpopup" class="popmain1">
  <div class="fancybox_content">

    <h5>You have not registered for this event </h5>
    <br>
    <div class="btn1"><a href="https://lp.crn.in/lmi/iam-virtual-conference/register.php" target="_blank"
        title="Close">Register</a>
    </div>
  </div>
</div>

 <div id="resigterpopup1" class="popmain1">
  <div class="fancybox_content">

    <h5>Thank you for login, Conference will start at 2PM on 8th June 2021</h5>
   
    </div>
  </div>

  <div id="loginpop" class="popmain1">
    <div class="fancybox_content">
      <h3>VIRTUAL CONFERENCE </h3>
      <h2>Data Breaches in the post pandemic world      </h2>
      <h4>will be live on</h4>
      <br>
      <h5>8<sup>th</sup> June 2021 | 02:00 PM IST </h5>
      <br>
      <div class="btn1"><a href="javascript:" data-fancybox-close="" title="Close">OK</a>
      </div>
    </div>
  </div>
</div>
  <?php $__env->stopSection(); ?>


  <?php $__env->startSection('customJs'); ?>
  <script src="js/jquery.fancybox.min.js" type="text/javascript"></script>

  <script src="https://ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.js"></script>
<script type="text/javascript">
  $(document).ready(function () {
          //openCity(event, 'tue2');

          $('button').attr('disabled',false);
          // login page validation
          $("#loginFrm").validate({
            rules: {
              email: { required: true, email: true },
            },
            messages: {
              email: {
                required: "Please enter your email address",
                email: "Please enter valid email address"
              },
            },
          submitHandler: function(form) {            

              $.ajax({
                url: 'ajaxlogin',
                data:{email: $("#email").val(), _token: $("input[name='_token']").val() },
                type: 'post',
                dataType: 'json',
                success: function(response){
                  if(response.status == 200){
                  // if($("#email").val() == 'sangita.kendre@indianexpress.com'){
                    $("#loginFrm")[0].submit();
                  //  }else{
                  //   $.fancybox.open($("#loginpop"));

                  //  }
                   //   $("#loginFrm")[0].submit();
                  }else{
                    $.fancybox.open($("#resigterpopup"));
                  }
                }
              });

              return false;
            
            }
          });
        });




</script>
  <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/panel.expressbpd.in/public_html/demo/resources/views/pages/home.blade.php ENDPATH**/ ?>