<?php

namespace App\odels;

use Illuminate\Database\Eloquent\Model;

class videoMeetModel extends Model
{
    protected $table = 'dts_video_meet';

    protected $fillable = [];

    public $timestamps = false;
}
